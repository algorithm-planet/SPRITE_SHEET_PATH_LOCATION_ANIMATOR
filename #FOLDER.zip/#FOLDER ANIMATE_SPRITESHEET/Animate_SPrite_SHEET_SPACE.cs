﻿using UnityEngine;
using System.Collections;

namespace Animate_SPRITE_SHEET_SPACE
{
    public static class C
    {
        public static Vector2 r = Vector2.right,
                             up = Vector2.up,
                           zero = Vector2.zero;




            
    }
}
