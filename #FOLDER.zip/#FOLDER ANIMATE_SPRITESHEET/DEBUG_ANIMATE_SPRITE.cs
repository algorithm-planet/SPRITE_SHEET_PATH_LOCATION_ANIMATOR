﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Animate_SPRITE_SHEET_SPACE;


public class DEBUG_ANIMATE_SPRITE : MonoBehaviour
{

    public string image_path_location;
    public string image_name;


    Transform holder;
    private void Update()
    {
        if(Input.GetMouseButtonDown(1))
        {
            if (holder != null) Destroy(holder.gameObject);
            holder = new GameObject("holder").transform;

            StopAllCoroutines();
            StartCoroutine(STIMULATE());
        }
    }



    IEnumerator STIMULATE()
    {
        Material mat = new Material(Shader.Find("Unlit/Transparent"));

        Mesh quad = new Mesh()
        {
            vertices = new Vector3[4]
            {
                (-C.r - C.up)/2,
                (-C.r + C.up )/2,
                ( C.r + C.up )/2,
                ( C.r - C.up )/2,
            },
            uv = new Vector2[4]
            {C.zero , C.up , C.r +  C.up , C.r},

            triangles = new int[2 * 3]
            {
                0 , 1 , 2,
                0 , 2 , 3
            }
        };


        GameObject G = new GameObject("@object");
        Transform transform = G.transform;
        transform.parent = holder;

        MeshFilter mf = G.AddComponent<MeshFilter>();
        MeshRenderer mr = G.AddComponent<MeshRenderer>();

        mf.sharedMesh =  quad;
        mr.sharedMaterial = mat;


        image_path_location = a.text;
        image_name = b.text;
        splits = (int)slider.value;


        //

        Texture2D load = LOAD_IMAGE_FROM_PATH_NAME(this.image_path_location , this.image_name); 
        mr.sharedMaterial.mainTexture = load;

        transform.localScale = new Vector3(load.width * 1f / load.height * 1f/splits, 1, 1);



        mat.mainTextureScale = new Vector2(1f / splits, 1);
        while(true)
        {
            for(int i =0; i < splits; i += 1)
            {
                mat.mainTextureOffset = new Vector2( 1f/splits * i, 0);

                yield return new WaitForSeconds(0.5f * 1f / 8);
            }


        }






        Debug.Log(image_path_location[2].GetHashCode() + " // " + @"\".GetHashCode());
        yield return null;
    }


    public TMPro.TMP_InputField a, b;
    public UnityEngine.UI.Slider slider;


    [Range(1, 10)]
    public int splits = 2;

    Texture2D LOAD_IMAGE_FROM_PATH_NAME(string path_location , string image_name)
    {
        string path = path_location + "/" +  this.image_name;

        if (System.IO.File.Exists(path))
        {
            byte[] bytes = System.IO.File.ReadAllBytes(path);
            Texture2D texture2D = new Texture2D(1, 1);
            texture2D.wrapMode = TextureWrapMode.Clamp;

            bool loaded = texture2D.LoadImage(bytes);
            if (loaded)
                return texture2D;

        }

        #region ad .png .jpg
        else if (System.IO.File.Exists(path + ".png"))
        {
            byte[] bytes = System.IO.File.ReadAllBytes(path + ".png");
            Texture2D texture2D = new Texture2D(1, 1);
            texture2D.wrapMode = TextureWrapMode.Clamp;

            bool loaded = texture2D.LoadImage(bytes);
            if (loaded)
                return texture2D;
        }
        else if (System.IO.File.Exists(path + ".jpg"))
        {
            byte[] bytes = System.IO.File.ReadAllBytes(path + ".jpg");
            Texture2D texture2D = new Texture2D(1, 1);
            texture2D.wrapMode = TextureWrapMode.Clamp;

            bool loaded = texture2D.LoadImage(bytes);
            if (loaded)
                return texture2D;
        }

        #endregion
        return null;
    }

}
